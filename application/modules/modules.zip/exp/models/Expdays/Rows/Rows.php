<?php
class Exp_Model_expdays_Row extends Core_Db_Table_Row_Abstract

{
   
}