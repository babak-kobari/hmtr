<?php
class Exp_Model_exppoidetail_Row extends Core_Db_Table_Row_Abstract

{
   
}