<?php
class Poi_Model_poifacl_Row extends Core_Db_Table_Row_Abstract

{
   
}